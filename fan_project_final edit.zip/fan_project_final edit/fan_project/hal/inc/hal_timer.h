#ifndef HAL_TIMER_H
#define HAL_TIMER_H

#include <stdint.h>

typedef void (*HalTimerCallback_t)(void);

void HalTimer_Init(void);
void HalTimer_SetTimer(uint32_t seconds);
void HalTimer_RegisterCallback(HalTimerCallback_t callback);
uint32_t HalTimer_GetSeconds(void);

#endif /* HAL_TIMER_H */
