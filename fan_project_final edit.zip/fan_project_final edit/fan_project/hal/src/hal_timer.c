/* Dummy timer driver: the host clock replaces the hardware counter. */

#include <stdio.h>
#include <time.h>
#include <unistd.h>

#include "hal_timer.h"

static time_t start_time;
static HalTimerCallback_t timer_callback;

void HalTimer_Init(void)
{
  start_time = time(NULL);
  timer_callback = NULL;
  printf("[HAL/TIMER] init, 1 s resolution\n");
}

void HalTimer_RegisterCallback(HalTimerCallback_t callback)
{
  timer_callback = callback;
}

void HalTimer_SetTimer(uint32_t seconds)
{
  printf("[HAL/TIMER] Set Timer for %lu seconds\n", (unsigned long)seconds);
  sleep(seconds);

  if (timer_callback != NULL)
  {
    timer_callback();
  }
}

uint32_t HalTimer_GetSeconds(void)
{
  return (uint32_t)(time(NULL) - start_time);
}
